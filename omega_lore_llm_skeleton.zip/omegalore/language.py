"""Toy language utilities for Ω‑LORE.

This module defines a simple integer token vocabulary and embedding table.
In a real system you would replace this with a tokenizer for natural language
and learned embeddings. Here we keep things minimal to illustrate how
the brain simulator interfaces with token representations.
"""

from typing import Dict, Tuple
import numpy as np

from .config import OmegaConfig


class ToyVocab:
    """Simple integer vocabulary for demonstration."""

    def __init__(self, vocab_size: int) -> None:
        self.vocab_size = vocab_size
        # Map each integer token to itself
        self.idx_to_token: Dict[int, str] = {i: str(i) for i in range(vocab_size)}
        self.token_to_idx: Dict[str, int] = {str(i): i for i in range(vocab_size)}

    def encode(self, token: str) -> int:
        return self.token_to_idx[token]

    def decode(self, idx: int) -> str:
        return self.idx_to_token[idx]


class EmbeddingTable:
    """Embedding table for encoder area."""

    def __init__(self, config: OmegaConfig, vocab_size: int) -> None:
        n_enc = config.areas["encoder"].n_neurons
        # Random normal initialisation scaled down
        self.embeddings = np.random.randn(vocab_size, n_enc).astype(np.float32) * 0.1

    def __call__(self, idx: int) -> np.ndarray:
        return self.embeddings[idx]