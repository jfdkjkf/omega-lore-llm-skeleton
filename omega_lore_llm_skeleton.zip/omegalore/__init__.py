"""Ω‑LORE package root.

This package exposes a set of high‑level classes and functions for building and
running simplified Ω‑LORE models. Importing this package will not perform any
heavy computations.
"""

from .config import OmegaConfig, AreaConfig
from .model import OmegaLoreBrain

__all__ = [
    "OmegaConfig",
    "AreaConfig",
    "OmegaLoreBrain",
]