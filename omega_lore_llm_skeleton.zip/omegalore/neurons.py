"""Simplified neural dynamics for Ω‑LORE.

This module provides a toy implementation of leaky integrate‑and‑fire (LIF) areas
and synapses. It is not a full spiking simulator but serves to illustrate
how areas might interact and how local Hebbian learning rules could be
structured.
"""

from dataclasses import dataclass
from typing import Dict, Tuple
import numpy as np

from .config import OmegaConfig
from .schema import BrainSchema


@dataclass
class LIFArea:
    """Represents a population of LIF neurons in an area.

    Attributes
    ----------
    n_neurons:
        Number of neurons in the population.
    tau:
        Membrane time constant.
    dt:
        Simulation time step.
    v:
        Membrane potentials of the neurons.
    trace:
        Low‑pass filtered activity (acts as post‑synaptic trace for learning).
    """

    n_neurons: int
    tau: float
    dt: float
    v: np.ndarray
    trace: np.ndarray

    @staticmethod
    def create(n_neurons: int, tau: float, dt: float) -> "LIFArea":
        v = np.zeros(n_neurons, dtype=np.float32)
        trace = np.zeros(n_neurons, dtype=np.float32)
        return LIFArea(n_neurons, tau, dt, v, trace)

    def reset(self) -> None:
        self.v.fill(0.0)
        self.trace.fill(0.0)

    def step(self, input_current: np.ndarray) -> np.ndarray:
        """Advance the membrane potentials by one time step.

        This is a very simple first‑order approximation to LIF dynamics without
        spike resets. Real spiking behaviour can be added later.
        """
        dv = (-self.v + input_current) * (self.dt / self.tau)
        self.v += dv
        # Use a simple rectification as a proxy for firing rate
        rates = np.maximum(self.v, 0.0)
        # Update trace with exponential decay
        self.trace += (rates - self.trace) * (self.dt / self.tau)
        return rates


class Synapse:
    """Simple synapse connecting two areas.

    The synapse holds a weight matrix and implements Hebbian plasticity.
    For efficiency this skeleton does not implement individual synapse traces
    but instead reuses the pre‑ and post‑synaptic traces from the areas.
    """

    def __init__(self, pre_size: int, post_size: int, lr: float, decay: float) -> None:
        self.w = np.random.randn(post_size, pre_size).astype(np.float32) * 0.01
        self.lr = lr
        self.decay = decay

    def compute_input(self, pre_rates: np.ndarray) -> np.ndarray:
        """Compute the input current to the post‑synaptic area."""
        return self.w @ pre_rates

    def update(self, pre_trace: np.ndarray, post_trace: np.ndarray, modulatory: float) -> None:
        """Apply a local three‑factor Hebbian update.

        Parameters
        ----------
        pre_trace:
            Low‑pass filtered activity of the pre‑synaptic neurons.
        post_trace:
            Low‑pass filtered activity of the post‑synaptic neurons.
        modulatory:
            Error‑driven modulatory factor from the critic. In a real system
            this would depend on prediction error; here it is passed in as a
            scalar.
        """
        # Outer product of traces yields a matrix of correlations
        delta = modulatory * np.outer(post_trace, pre_trace)
        self.w += self.lr * (delta - self.decay * self.w)


class NeuralDynamics:
    """Container holding areas and synapses for an Ω‑LORE brain.

    This class orchestrates the forward updates and learning across areas.
    """

    def __init__(self, config: OmegaConfig) -> None:
        self.config = config
        self.schema = BrainSchema(config)
        # Create LIF areas
        self.areas: Dict[str, LIFArea] = {}
        for name, cfg in config.areas.items():
            self.areas[name] = LIFArea.create(cfg.n_neurons, cfg.time_constant, config.dt)
        # Create synapses keyed by (source, target)
        self.synapses: Dict[Tuple[str, str], Synapse] = {}
        for conn in self.schema.connections:
            pre_size = self.config.areas[conn.source].n_neurons
            post_size = self.config.areas[conn.target].n_neurons
            self.synapses[(conn.source, conn.target)] = Synapse(pre_size, post_size, lr=config.learning_rate, decay=config.weight_decay)

    def reset_state(self) -> None:
        for area in self.areas.values():
            area.reset()

    def step(self, external_inputs: Dict[str, np.ndarray], modulatory: float = 0.0) -> Dict[str, np.ndarray]:
        """Perform a single simulation step.

        Parameters
        ----------
        external_inputs:
            Mapping from area name to input current array. Only specified areas
            will receive external current. Others will default to zero.
        modulatory:
            Scalar modulatory factor applied globally to all synapses during
            learning. In practice this would be computed by a critic network.
        Returns
        -------
        rates:
            Dictionary mapping area names to their instantaneous firing rates.
        """
        # Compute inputs for each area
        total_input: Dict[str, np.ndarray] = {}
        for name, area in self.areas.items():
            # Start with external input if provided
            total = external_inputs.get(name, np.zeros(area.n_neurons, dtype=np.float32))
            # Sum contributions from all incoming synapses
            for src in self.schema.get_sources_for(name):
                syn = self.synapses[(src, name)]
                pre_rates = self.areas[src].trace  # use trace as a proxy for rate
                total += syn.compute_input(pre_rates)
            total_input[name] = total
        # Update areas and collect rates
        rates: Dict[str, np.ndarray] = {}
        for name, area in self.areas.items():
            rates[name] = area.step(total_input[name])
        # Apply learning
        if modulatory != 0.0:
            for (src, tgt), syn in self.synapses.items():
                pre_trace = self.areas[src].trace
                post_trace = self.areas[tgt].trace
                syn.update(pre_trace, post_trace, modulatory)
        return rates