"""Defines the neural schema for an Ω‑LORE brain.

In Ω‑LORE each brain area is treated as a population of neurons with its own
membrane dynamics and incoming synapses. This module defines data structures
that encapsulate the sparse connectivity graph and provide helper methods
for building weight matrices.
"""

from dataclasses import dataclass
from typing import Dict, List

from .config import OmegaConfig


@dataclass
class Connection:
    """Represents a connection between two areas.

    Attributes
    ----------
    source:
        Name of the source area.
    target:
        Name of the target area.
    """

    source: str
    target: str


class BrainSchema:
    """Brain schema capturing areas and connectivity.

    The schema does not store the actual weight matrices but defines which
    connections exist between areas. The model can use this information to
    allocate weight matrices and update them during learning.
    """

    def __init__(self, config: OmegaConfig) -> None:
        self.config = config
        self.connections: List[Connection] = []
        for tgt_name, area_cfg in config.areas.items():
            for src_name in area_cfg.inputs:
                self.connections.append(Connection(source=src_name, target=tgt_name))

    def get_targets_for(self, source: str) -> List[str]:
        """Return a list of areas that receive input from the given source."""
        return [conn.target for conn in self.connections if conn.source == source]

    def get_sources_for(self, target: str) -> List[str]:
        """Return a list of areas that project into the given target."""
        return [conn.source for conn in self.connections if conn.target == target]

    def area_names(self) -> List[str]:
        """Return the list of area names in the schema."""
        return list(self.config.areas.keys())