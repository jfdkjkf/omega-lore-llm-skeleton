"""High‑level simulation functions for Ω‑LORE.

This module wraps the low‑level neural dynamics into functions that advance the
state of the brain for one token or a sequence of tokens. It is deliberately
simple: most of the heavy lifting is delegated to the `NeuralDynamics`
class, while this module defines the token loop and modulatory signal
computation used during training.
"""

from typing import Dict, List, Optional, Tuple
import numpy as np

from .config import OmegaConfig
from .neurons import NeuralDynamics


class BrainSimulator:
    """Wrapper for stepping through tokens with Ω‑LORE dynamics."""

    def __init__(self, config: OmegaConfig, vocab_size: int) -> None:
        self.config = config
        self.vocab_size = vocab_size
        self.dynamics = NeuralDynamics(config)
        # Readout weight matrix from predictor area to logits
        n_pred = config.areas["predictor"].n_neurons
        self.readout = np.random.randn(vocab_size, n_pred).astype(np.float32) * 0.01

    def reset_state(self) -> None:
        self.dynamics.reset_state()

    def run_token(self, token_embed: np.ndarray, modulatory: float = 0.0) -> np.ndarray:
        """Run the brain dynamics for one token.

        Parameters
        ----------
        token_embed:
            Embedding vector for the input token. Must match encoder area size.
        modulatory:
            Scalar modulatory factor applied to learning. Non‑zero only during training.
        Returns
        -------
        logits:
            Output logits for the next token, computed from the predictor area.
        """
        external: Dict[str, np.ndarray] = {"encoder": token_embed}
        for _ in range(self.config.n_steps_per_token):
            self.dynamics.step(external_inputs=external, modulatory=modulatory)
            # After first step, zero out external input to avoid repeated injection
            external = {}
        # Compute logits from predictor area
        pred_rates = self.dynamics.areas["predictor"].trace
        logits = self.readout @ pred_rates
        return logits