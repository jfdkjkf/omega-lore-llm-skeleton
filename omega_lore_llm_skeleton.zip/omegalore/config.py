"""Configuration structures for the Ω‑LORE model.

This module defines dataclasses that capture the sizes and hyperparameters
needed to build an Ω‑LORE brain. These classes are intentionally lightweight
and self‑documenting. Feel free to extend them with additional fields as
needed for experimentation.
"""

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class AreaConfig:
    """Configuration for a single neural area.

    Attributes
    ----------
    name:
        Human‑readable name of the area.
    n_neurons:
        Number of neurons in this area. In a real implementation this would
        determine the dimensionality of the state vectors. For this skeleton
        the number is not used directly but serves to document intended scale.
    time_constant:
        Time constant (in arbitrary units) for membrane dynamics in this area.
    inputs:
        Names of areas that project into this area. This field does not
        enforce connectivity by itself but documents the intended wiring.
    """

    name: str
    n_neurons: int
    time_constant: float
    inputs: List[str] = field(default_factory=list)


@dataclass
class OmegaConfig:
    """Top‑level configuration for an Ω‑LORE brain.

    This dataclass collects configurations for each area and global
    hyperparameters such as learning rates.
    """

    areas: Dict[str, AreaConfig]
    dt: float = 0.1
    learning_rate: float = 1e‑3
    weight_decay: float = 1e‑5
    n_steps_per_token: int = 10

    @staticmethod
    def default() -> "OmegaConfig":
        """Create a reasonable default configuration.

        The default includes six areas representing encoder, semantic, grammar,
        context, predictor and critic. Sizes are intentionally small for a toy
        demonstration.
        """
        areas = {
            "encoder": AreaConfig("encoder", n_neurons=64, time_constant=20.0, inputs=[]),
            "semantic": AreaConfig("semantic", n_neurons=128, time_constant=30.0, inputs=["encoder", "context"]),
            "grammar": AreaConfig("grammar", n_neurons=64, time_constant=25.0, inputs=["encoder", "semantic"]),
            "context": AreaConfig("context", n_neurons=64, time_constant=40.0, inputs=["semantic", "grammar"]),
            "predictor": AreaConfig("predictor", n_neurons=32, time_constant=15.0, inputs=["semantic", "grammar", "context"]),
            "critic": AreaConfig("critic", n_neurons=16, time_constant=15.0, inputs=["predictor"]),
        }
        return OmegaConfig(areas=areas)