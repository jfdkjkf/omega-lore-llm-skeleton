"""High‑level Ω‑LORE brain model.

This module exposes the `OmegaLoreBrain` class which glues together the
configuration, language utilities and brain simulator. It provides methods
for running forward predictions and for performing simple training on a
sequence of integer tokens using cross‑entropy loss. The learning rule
implemented here uses a constant modulatory factor for Hebbian updates,
serving as a placeholder for a critic network in a more complete model.
"""

from typing import List, Tuple
import numpy as np

from .config import OmegaConfig
from .language import ToyVocab, EmbeddingTable
from .dynamics import BrainSimulator


class OmegaLoreBrain:
    """Simplified Ω‑LORE brain exposing prediction and training APIs."""

    def __init__(self, vocab_size: int, config: OmegaConfig) -> None:
        self.config = config
        self.vocab = ToyVocab(vocab_size)
        self.embed = EmbeddingTable(config, vocab_size)
        self.sim = BrainSimulator(config, vocab_size)
        self.vocab_size = vocab_size

    @staticmethod
    def softmax(x: np.ndarray) -> np.ndarray:
        e = np.exp(x - np.max(x))
        return e / e.sum()

    def reset_state(self) -> None:
        self.sim.reset_state()

    def predict_next(self, context: List[int]) -> int:
        """Predict the next token given a context.

        This method will feed the context tokens into the brain one by one
        without learning and return the most likely next token.
        """
        self.reset_state()
        for idx in context:
            embed = self.embed(idx)
            logits = self.sim.run_token(embed, modulatory=0.0)
        probs = self.softmax(logits)
        return int(np.argmax(probs))

    def training_step(self, sequence: List[int]) -> float:
        """Perform a training update on a sequence of integer tokens.

        The method feeds each token to the brain and computes the cross‑entropy
        loss against the next token. Hebbian learning is driven by a constant
        modulatory factor for simplicity.

        Parameters
        ----------
        sequence:
            List of token indices representing the training example.

        Returns
        -------
        loss:
            Total cross‑entropy loss over the sequence (average per token).
        """
        self.reset_state()
        total_loss = 0.0
        n = len(sequence) - 1
        if n <= 0:
            return 0.0
        for t in range(n):
            token_idx = sequence[t]
            target_idx = sequence[t + 1]
            embed = self.embed(token_idx)
            logits = self.sim.run_token(embed, modulatory=1.0)  # use constant modulatory
            probs = self.softmax(logits)
            # Cross‑entropy loss
            loss = -np.log(probs[target_idx] + 1e‑12)
            total_loss += loss
        return total_loss / n