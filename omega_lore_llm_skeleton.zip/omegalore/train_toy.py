"""Toy training script for the Ω‑LORE skeleton.

This script demonstrates how to instantiate the Ω‑LORE brain, generate a
synthetic dataset of integer sequences, and perform a few training epochs. It
prints the average loss and shows predictions on a held‑out test example.
"""

import numpy as np
from .config import OmegaConfig
from .model import OmegaLoreBrain


def generate_dataset(num_sequences: int, seq_length: int, vocab_size: int) -> list[list[int]]:
    """Generate a list of random integer sequences."""
    return [list(np.random.randint(0, vocab_size, size=seq_length + 1)) for _ in range(num_sequences)]


def main() -> None:
    vocab_size = 10
    config = OmegaConfig.default()
    brain = OmegaLoreBrain(vocab_size, config)

    # Generate dataset
    train_data = generate_dataset(100, 4, vocab_size)
    test_seq = generate_dataset(1, 4, vocab_size)[0]

    for epoch in range(3):
        np.random.shuffle(train_data)
        total_loss = 0.0
        for seq in train_data:
            loss = brain.training_step(seq)
            total_loss += loss
        avg_loss = total_loss / len(train_data)
        print(f"Epoch {epoch + 1}: avg loss = {avg_loss:.4f}")

    # Test prediction
    print("Test sequence:", test_seq[:-1])
    brain.reset_state()
    for idx in test_seq[:-1]:
        embed = brain.embed(idx)
        brain.sim.run_token(embed, modulatory=0.0)
    logits = brain.sim.run_token(brain.embed(test_seq[-2]), modulatory=0.0)
    probs = brain.softmax(logits)
    pred = int(np.argmax(probs))
    print("Predicted next token:", pred, "(target:", test_seq[-1], ")")


if __name__ == "__main__":
    main()